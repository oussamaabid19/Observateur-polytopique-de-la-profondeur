function R = ch02_run()
%CH02_RUN  Numerical study of Chapter 2: polytopic (TS) depth observer,
%          LMI synthesis and structural role of the output-injection gain.
%
%   R = ch02_run()
%
%   1. LMI synthesis of the Lipschitz polytopic observer (YALMIP + SeDuMi)
%      and diagnostic LMI problems (vacuity of the relaxed LMI, quadratic
%      stabilisation obstruction).
%   2. Multilinear (Walsh) expansion of the TS-interpolated gain.
%   3. Observer simulations with ode45 (tight tolerances) and explicit
%      Euler, then a family of gain modifications that isolates the part of
%      L acting on the inverse depth.
%   4. Reduced (singular-perturbation) prediction of the depth error and
%      persistency-of-excitation indicators.
%
%   Outputs are written to ../fig (CSV + ch02_numbers.tex) and
%   code/results/ch02_results.mat. No Simulink; ode45 only.

here   = fileparts(mfilename('fullpath'));
figDir = fullfile(here, '..', 'fig');
resDir = fullfile(here, 'results');
if ~exist(resDir, 'dir'), mkdir(resDir); end
ch02_setup_path();

%% Model and polytope ------------------------------------------------------
base.A0    = zeros(3);
base.Acell = {[0 0 1; 0 0 0; 0 0 0], [0 0 0; 0 0 1; 0 0 0], [0 0 0; 0 0 0; 0 0 1]};
base.C     = [1 0 0; 0 1 0];
C = base.C;
box = base;  box.pmin = -5*ones(3, 1);  box.pmax = 5*ones(3, 1);
[~, ~, Avert] = ts_system([], box);

%% 1. LMI problems ----------------------------------------------------------
fprintf('\n=== Chapter 2: LMI problems ===\n');
L1 = lmi_lipschitz_observer(Avert, C, -1e-3, 1e-12);                                  % reference design
L2 = lmi_lipschitz_observer(Avert, C, -1e-3, 1e-12, struct('Rzero', true));          % no injection
L3 = lmi_lipschitz_observer(Avert, C, -1e-3, 1e-12, struct('Pmin', 1));              % normalised P
L4 = lmi_lipschitz_observer(Avert, C, 0, 1e-6, struct('Pmin', 1));                   % no relaxation
boxNeg = base;  boxNeg.pmin = [-5; -5; -5];  boxNeg.pmax = [5; 5; -0.1];
[~, ~, AvertNeg] = ts_system([], boxNeg);
Q1 = lmi_quadratic_stab(Avert,    C, 0,    1e-6);
Q2 = lmi_quadratic_stab(AvertNeg, C, 0.05, 1e-6);
Q3 = lmi_quadratic_stab(AvertNeg, C, 0.2,  1e-6);
lmiCases = {L1, L2, L3, L4};
for c = 1:4
    S = lmiCases{c};
    fprintf('Lipschitz LMI case %d: problem %d (%s), feasible %d\n', c, S.problem, S.info, S.feasible);
end
fprintf('QS full box sigma=0     : problem %d feasible %d\n', Q1.problem, Q1.feasible);
fprintf('QS p3<=-0.1 sigma=0.05  : problem %d feasible %d\n', Q2.problem, Q2.feasible);
fprintf('QS p3<=-0.1 sigma=0.2   : problem %d feasible %d\n', Q3.problem, Q3.feasible);

S0 = L1;
if ~S0.feasible
    warning('ch02:lmi', 'Reference LMI reported as not feasible by the a posteriori check.');
end
params = box;  params.Lvert = S0.L;
fprintf('P eigenvalues: %s   cond(P) = %.3g   gamma = %.4g\n', mat2str(S0.eigP, 4), S0.condP, S0.gamma);

%% 2. Walsh expansion of the gain ------------------------------------------
[Lam, subsets] = ts_walsh(S0.L, 3);
lamNorm = cellfun(@(M) norm(M, 2), Lam);
jC  = 1;                                    % constant part
j1  = find(ismember(subsets, [1 0 0], 'rows'));
j2  = find(ismember(subsets, [0 1 0], 'rows'));
ell = mean(diag(Lam{jC}(1:2, 1:2)));        % image-row gain
kv  = mean([Lam{j1}(3, 1), Lam{j2}(3, 2)]); % depth-row coefficient on xi_1, xi_2
kappa = kv/box.pmax(1);                     % coefficient on p1, p2
ratioP = mean(diag(S0.P(1:2, 1:2)))/S0.P(3, 3);
offDepth = max([norm(Lam{jC}(3, :)), norm(Lam{j1}(3, 2)), norm(Lam{j2}(3, 1))]);
fprintf('Walsh: ell = %.4f  kappa_v = %.4f  kappa = %.4f  P_s/P_chi = %.4f\n', ell, kv, kappa, ratioP);
for j = 1:8
    fprintf('  S = {%s}  ||Lam_S|| = %.3e\n', num2str(find(subsets(j, :))), lamNorm(j));
end

%% 3. Simulations ------------------------------------------------------------
u   = @(t) [0.7*cos(2*pi*t); 0.5*cos(pi*t/2); cos(pi*t); 0.1*cos(pi*t/2); 0; 0.1];
q0  = [0; 0; 0.25];
qh0 = [0; 0; 0.5];
T   = 10;  dt = 0.01;  tg = (0:dt:T).';
opts = odeset('RelTol', 1e-8, 'AbsTol', 1e-10);

% PE indicators (true trajectory, independent of the observer)
nom = simulate(struct(), params, u, q0, qh0, tg, opts);
rho = sum(nom.Om.^2, 2);
win = 1.0;  nw = round(win/dt);
peInt = zeros(numel(tg) - nw, 1);
for k = 1:numel(peInt), peInt(k) = trapz(tg(k:k+nw), rho(k:k+nw)); end
alphaObs = 0.1;
fov = max(abs(nom.q(:, 1:2)), [], 2);
rhoMean = mean(rho);

ellC = 2*sqrt(kappa*rhoMean);                    % critical damping of the depth mode
variants = { ...                                 % CSV column, modification, LaTeX tag
    'nominal', struct(),                       'Nom'; ...
    'c01',     struct('cs', 0.1, 'c3', 0.1),   'Small'; ...
    'c10',     struct('cs', 10,  'c3', 10),    'Large'; ...
    'mean',    struct('gain', 'mean'),         'Mean'; ...
    'ls05',    struct('cs', 0.5),              'LsHalf'; ...
    'ls2',     struct('cs', 2),                'LsDouble'; ...
    'l305',    struct('c3', 0.5),              'LdHalf'; ...
    'l32',     struct('c3', 2),                'LdDouble'; ...
    'crit',    struct('cs', ellC/ell),         'Crit'};
nv = size(variants, 1);
eAbs = zeros(numel(tg), nv);
tSet = nan(1, nv);  eEnd = zeros(1, nv);
for i = 1:nv
    if i == 1, ri = nom; else, ri = simulate(variants{i, 2}, params, u, q0, qh0, tg, opts); end
    e = abs(ri.q(:, 3) - ri.qh(:, 3));
    eAbs(:, i) = e;
    eEnd(i) = e(end);
    tSet(i) = settling(tg, e, 0.01*abs(q0(3) - qh0(3)));
    fprintf('variant %-8s  |e_chi(T)| = %.3e   t_1%% = %.2f s\n', variants{i, 1}, eEnd(i), tSet(i));
end

% Explicit Euler with the step of the original study
eul = eulerSim(params, u, q0, qh0, tg);

% Structural (linear time-varying) error model along the nominal run:
%   de_s/dt = -L_s e_s + Omega(s,v) e_chi ,  de_chi/dt = -L_3 e_s + mu e_chi
% with L = L(ph(t)) and mu = v_z (chi + chih) + y w_x - x w_y.
Lt = zeros(numel(tg), 6);  mu = zeros(numel(tg), 1);  maxRe = mu;
for k = 1:numel(tg)
    q = nom.q(k, :).';  qh = nom.qh(k, :).';  uk = u(tg(k));  v = uk(1:3);  w = uk(4:6);
    ph = [qh(1)*v(3) - v(1); qh(2)*v(3) - v(2); v(3)*qh(3) + qh(2)*w(1) - qh(1)*w(2)];
    [A, h] = ts_system(ph, params);
    L = zeros(3, 2);  for j = 1:8, L = L + h(j)*params.Lvert{j}; end
    Lt(k, :) = L(:).';
    mu(k) = v(3)*(q(3) + qh(3)) + q(2)*w(1) - q(1)*w(2);
    maxRe(k) = max(real(eig(A - L*C)));
end
fLtv = @(t, e) ltvRhs(t, e, tg, Lt, nom.Om, mu);
[~, eL] = ode45(fLtv, tg, q0 - qh0, opts);
eLtv = abs(eL(:, 3));

% Averaged mass-spring-damper model of the depth error:
%   e_chi'' + ell e_chi' + kappa <rho> e_chi = 0   (large-gain limit)
% predicted decay rate of the slowest mode vs measured envelope slope.
cs = ones(1, nv);  c3 = ones(1, nv);  kfac = ones(1, nv);
for i = 1:nv
    m = variants{i, 2};
    if isfield(m, 'cs'), cs(i) = m.cs; end
    if isfield(m, 'c3'), c3(i) = m.c3; end
    if isfield(m, 'gain') && strcmp(m.gain, 'mean'), kfac(i) = 0; end
end
ellV = cs*ell;  kapV = c3.*kfac*kappa;
rPred = zeros(1, nv);  rMeas = nan(1, nv);
for i = 1:nv
    disc = ellV(i)^2/4 - kapV(i)*rhoMean;
    if disc > 0, rPred(i) = ellV(i)/2 - sqrt(disc); else, rPred(i) = ellV(i)/2; end
    e = eAbs(:, i);  env = flipud(cummax(flipud(e)));  e0 = e(1);
    sel = env <= 0.3*e0 & env >= 1e-9*e0;
    if nnz(sel) > 10
        cf = polyfit(tg(sel), log(env(sel)), 1);  rMeas(i) = -cf(1);
    end
    fprintf('variant %-8s ell = %7.2f kappa = %8.2f  rate pred = %6.2f  meas = %6.2f\n', ...
            variants{i, 1}, ellV(i), kapV(i), rPred(i), rMeas(i));
end

%% Export -------------------------------------------------------------------
fl = 1e-12;
writeCsv(fullfile(figDir, 'ch02_states.csv'), ...
    {'t','x','y','chi','xh','yh','chih','xE','yE','chiE','xhE','yhE','chihE'}, ...
    [tg, nom.q, nom.qh, eul.q, eul.qh]);
writeCsv(fullfile(figDir, 'ch02_gains.csv'), ['t', variants(:, 1).'], [tg, max(eAbs, fl)]);
writeCsv(fullfile(figDir, 'ch02_reduced.csv'), ...
    {'t','echi','eltv','mu','rho','maxre'}, ...
    [tg, max(eAbs(:, 1), fl), max(eLtv, fl), mu, rho, maxRe]);
writeCsv(fullfile(figDir, 'ch02_pe.csv'), {'t','int'}, [tg(1:numel(peInt)), peInt]);

fid = fopen(fullfile(figDir, 'ch02_numbers.tex'), 'w');
fprintf(fid, '%% Generated by code/ch02_run.m -- do not edit by hand\n');
fprintf(fid, '%% MATLAB %s, %s\n', version('-release'), datestr(now, 'yyyy-mm-dd HH:MM'));
mac(fid, 'MatlabRelease', version('-release'));
tags = {'A', 'B', 'C', 'D'};
for c = 1:4
    S = lmiCases{c};
    mac(fid, ['Lmi' tags{c} 'Feas'], yesno(S.feasible));
    mac(fid, ['Lmi' tags{c} 'Prob'], sprintf('%d', S.problem));
    if isfield(S, 'eigP')
        mac(fid, ['Lmi' tags{c} 'Pmin'], sci(S.eigP(1)));
        mac(fid, ['Lmi' tags{c} 'Pmax'], sci(S.eigP(end)));
        mac(fid, ['Lmi' tags{c} 'Cond'], sci(S.condP));
        mac(fid, ['Lmi' tags{c} 'Gamma'], sprintf('%.3f', S.gamma));
    else
        mac(fid, ['Lmi' tags{c} 'Pmin'], '--');  mac(fid, ['Lmi' tags{c} 'Pmax'], '--');
        mac(fid, ['Lmi' tags{c} 'Cond'], '--');  mac(fid, ['Lmi' tags{c} 'Gamma'], '--');
    end
end
QS = {Q1, Q2, Q3};  qt = {'A', 'B', 'C'};
for c = 1:3
    mac(fid, ['Qs' qt{c} 'Feas'], yesno(QS{c}.feasible));
    mac(fid, ['Qs' qt{c} 'Prob'], sprintf('%d', QS{c}.problem));
end
mac(fid, 'Pss', sci(S0.P(1, 1)));  mac(fid, 'Pcc', sci(S0.P(3, 3)));
mac(fid, 'Pratio', sprintf('%.2f', ratioP));
mac(fid, 'Eta', sci(S0.eta));  mac(fid, 'Lambda', sci(S0.lambda));
mac(fid, 'Ell', sprintf('%.2f', ell));  mac(fid, 'Kv', sprintf('%.1f', kv));
mac(fid, 'Kappa', sprintf('%.2f', kappa));
mac(fid, 'KappaEll', sprintf('%.3f', kappa/ell));
mac(fid, 'OffDepth', sci(offDepth));
mac(fid, 'Absc', sprintf('%.2f', S0.absc));
names = {'C', 'Z', 'Y', 'YZ', 'X', 'XZ', 'XY', 'XYZ'};   % subset labels (x=1,y=2,z=3)
for j = 1:8
    mac(fid, ['Walsh' names{j}], sci(lamNorm(j)));
    mac(fid, ['Walsh' names{j} 'raw'], sprintf('%.6e', lamNorm(j)));
end
for j = 1:8
    Lk = S0.L{j};
    for a = 1:3
        for b = 1:2
            mac(fid, sprintf('Lv%s%s%s', char('A' + j - 1), char('a' + a - 1), char('a' + b - 1)), sprintf('%.2f', Lk(a, b)));
        end
    end
end
for i = 1:nv
    mac(fid, ['Var' variants{i, 3} 'End'], sci(eEnd(i)));
    mac(fid, ['Var' variants{i, 3} 'Set'], tsetStr(tSet(i)));
    mac(fid, ['Var' variants{i, 3} 'Ell'], sprintf('%.2f', ellV(i)));
    mac(fid, ['Var' variants{i, 3} 'Kap'], sprintf('%.1f', kapV(i)));
    mac(fid, ['Var' variants{i, 3} 'Pred'], sprintf('%.2f', rPred(i)));
    if isnan(rMeas(i)), mac(fid, ['Var' variants{i, 3} 'Meas'], '--');
    else, mac(fid, ['Var' variants{i, 3} 'Meas'], sprintf('%.2f', rMeas(i))); end
end
mac(fid, 'EllC', sprintf('%.2f', ellC));
mac(fid, 'RhoMean', sprintf('%.3f', rhoMean));
mac(fid, 'RhoMin', sci(min(rho)));
mac(fid, 'PeMin', sprintf('%.3f', min(peInt)));
mac(fid, 'PeWin', sprintf('%.0f', win));
mac(fid, 'AdmFrac', sprintf('%.1f', 100*mean(rho >= alphaObs^2)));
mac(fid, 'Fov', sprintf('%.3f', max(fov)));
mac(fid, 'FrozenUnstFrac', sprintf('%.1f', 100*mean(maxRe > 0)));
mac(fid, 'MaxReMax', sprintf('%.3f', max(maxRe)));
mac(fid, 'LtvMaxDiff', sci(max(abs(eLtv - eAbs(:, 1)))));
mac(fid, 'MuMean', sprintf('%.3f', mean(mu)));
mac(fid, 'EulerEnd', sci(abs(eul.qh(end, 3) - eul.q(end, 3))));
mac(fid, 'EulerCamDiff', sci(max(abs(eul.q(:, 3) - nom.q(:, 3)))));
mac(fid, 'OdeEnd', sci(eEnd(1)));
mac(fid, 'EulerOdeDiff', sci(max(abs(eul.qh(:, 3) - nom.qh(:, 3)))));
fclose(fid);

save(fullfile(resDir, 'ch02_results.mat'), 'L1', 'L2', 'L3', 'L4', 'Q1', 'Q2', 'Q3', ...
     'Lam', 'subsets', 'nom', 'eul', 'eAbs', 'variants', 'eLtv', 'mu', 'rho', 'maxRe', 'rPred', 'rMeas');
R = struct('S0', S0, 'Lam', {Lam}, 'nom', nom, 'eAbs', eAbs);
fprintf('Results written to %s\n', figDir);
end

%% ==========================================================================
function r = simulate(mod, params, u, q0, qh0, tg, opts)
f = @(t, z) rhs(t, z, mod, params, u);
[~, z] = ode45(f, tg, [q0; qh0], opts);
r.q = z(:, 1:3);  r.qh = z(:, 4:6);
r.Om = zeros(numel(tg), 2);
for k = 1:numel(tg)
    uk = u(tg(k));
    r.Om(k, :) = [r.q(k, 1)*uk(3) - uk(1), r.q(k, 2)*uk(3) - uk(2)];
end
end

function dz = rhs(t, z, mod, params, u)
uk = u(t);  v = uk(1:3);  w = uk(4:6);
dz = [cam_sys(z(1:3), v, w); obs_ts(z(4:6), v, w, z(1:2), params, mod)];
end

function r = eulerSim(params, u, q0, qh0, tg)
n = numel(tg);  q = q0;  qh = qh0;
r.q = zeros(n, 3);  r.qh = zeros(n, 3);  r.q(1, :) = q.';  r.qh(1, :) = qh.';
for k = 1:n-1
    h = tg(k+1) - tg(k);  uk = u(tg(k));  v = uk(1:3);  w = uk(4:6);
    dq  = cam_sys(q, v, w);
    dqh = obs_ts(qh, v, w, q(1:2), params);
    q = q + h*dq;  qh = qh + h*dqh;
    r.q(k+1, :) = q.';  r.qh(k+1, :) = qh.';
end
end

function de = ltvRhs(t, e, tg, Lt, Om, mu)
Lk = reshape(interp1(tg, Lt, t).', 3, 2);
Ok = interp1(tg, Om, t).';
mk = interp1(tg, mu, t);
de = [-Lk(1:2, :)*e(1:2) + Ok*e(3);
      -Lk(3, :)*e(1:2) + mk*e(3)];
end

function ts = settling(t, e, thr)
ts = NaN;
idx = find(e > thr, 1, 'last');
if isempty(idx), ts = 0; elseif idx < numel(t), ts = t(idx + 1); end
end

function s = tsetStr(x)
if isnan(x), s = '$>10$'; else, s = sprintf('%.2f', x); end
end

function mac(fid, name, val)
fprintf(fid, '\\newcommand{\\chTwo%s}{%s}\n', name, val);
end

function s = sci(x)
if x == 0, s = '0'; return, end
e = floor(log10(abs(x)));  m = x/10^e;
if abs(round(m*10)/10) >= 10, m = m/10; e = e + 1; end
s = sprintf('\\num{%.1fe%d}', m, e);
end

function s = yesno(b)
if b, s = 'yes'; else, s = 'no'; end
end

function writeCsv(file, header, M)
fid = fopen(file, 'w');
fprintf(fid, '%s', header{1});
fprintf(fid, ',%s', header{2:end});
fprintf(fid, '\n');
fmt = [repmat('%.10g,', 1, size(M, 2) - 1), '%.10g\n'];
fprintf(fid, fmt, M.');
fclose(fid);
end
