function dqh = obs_ts(qh, v, omega, y, params, mod)
%OBS_TS  Polytopic (TS) observer of the point-feature kinematics.
%
%   dqh = obs_ts(qh, v, omega, y, params, mod)
%
%   d qh/dt = sum_k h_k(ph) * ( A_k qh + L_k (y - C qh) ) + B(sh) omega
%
%   qh      estimated state [xh; yh; chih]
%   v,omega camera velocities (camera frame)
%   y       measured image point [x; y]
%   params  TS structure (Acell, pmin, pmax, A0) with fields
%             .C      output matrix [I2 0]
%             .Lvert  r-by-1 cell of vertex gains L_k (3-by-2)
%   mod     (optional) structure used to study the role of the gain:
%             .gain  'ts'   (default) L(ph) = sum_k h_k(ph) L_k
%                    'mean' constant gain (1/r) sum_k L_k
%             .cs    scaling of the image rows  L(1:2,:)   (default 1)
%             .c3    scaling of the depth row   L(3,:)     (default 1)
%
%   The scheduling variables are evaluated at the estimate (unmeasured
%   premise variables), as in the published design.

if nargin < 6 || isempty(mod), mod = struct(); end
if ~isfield(mod, 'gain'), mod.gain = 'ts'; end
if ~isfield(mod, 'cs'),   mod.cs = 1;      end
if ~isfield(mod, 'c3'),   mod.c3 = 1;      end

x = qh(1); yh = qh(2); chi = qh(3);
vx = v(1); vy = v(2); vz = v(3);
wx = omega(1); wy = omega(2);

ph = [x*vz - vx; yh*vz - vy; vz*chi + yh*wx - x*wy];
[A, h] = ts_system(ph, params);

r = numel(params.Lvert);
L = zeros(size(params.Lvert{1}));
switch mod.gain
    case 'ts'
        for k = 1:r, L = L + h(k)*params.Lvert{k}; end
    case 'mean'
        for k = 1:r, L = L + params.Lvert{k}/r; end
    otherwise
        error('obs_ts:gain', 'Unknown gain mode %s.', mod.gain);
end
L(1:2, :) = mod.cs*L(1:2, :);
L(3, :)   = mod.c3*L(3, :);

B = [x*yh, -(1 + x^2),  yh;
     1 + yh^2, -x*yh,  -x;
     0, 0, 0];

dqh = A*qh(:) + B*omega(:) + L*(y(:) - params.C*qh(:));
end
