function ch02_setup_path()
%CH02_SETUP_PATH  Add the LMI toolboxes shipped with the book to the path.
%
%   The LMI problems of Chapter 2 are modelled with YALMIP and solved with
%   SeDuMi. Both are open-source and are distributed with the book in
%   code/external/ (yalmip/ and sedumi/). If they are already on the MATLAB
%   path, nothing is changed.

here = fileparts(mfilename('fullpath'));
ext  = fullfile(here, 'external');
if exist('sdpvar', 'file') ~= 2
    addpath(genpath(fullfile(ext, 'yalmip')));
end
if exist('sedumi', 'file') ~= 2
    addpath(fullfile(ext, 'sedumi'));
end
if exist('sdpvar', 'file') ~= 2 || exist('sedumi', 'file') ~= 2
    error('ch02:toolbox', 'YALMIP and SeDuMi are required (see code/external).');
end
end
