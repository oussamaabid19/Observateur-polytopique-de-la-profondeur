function S = lmi_quadratic_stab(Avert, C, sigma, epsl)
%LMI_QUADRATIC_STAB  Quadratic stabilisation by output injection on a polytope.
%
%   S = lmi_quadratic_stab(Avert, C, sigma, epsl)
%
%   Find P = P' >= I and R_k such that, for every vertex k,
%       A_k' P + P A_k - C' R_k' - R_k C + 2 sigma P <= -epsl I ,
%   i.e. a common quadratic Lyapunov function V = e' P e certifying the
%   decay rate sigma for the closed loop sum_k h_k (A_k - L_k C),
%   L_k = P \ R_k. The normalisation P >= I removes the scaling freedom of
%   the homogeneous problem.

yalmip('clear');
r = numel(Avert);  n = size(Avert{1}, 1);  m = size(C, 1);
P = sdpvar(n, n, 'symmetric');
F = P >= eye(n);
R = cell(r, 1);
for k = 1:r
    R{k} = sdpvar(n, m, 'full');
    Phi = Avert{k}.'*P + P*Avert{k} - C.'*R{k}.' - R{k}*C + 2*sigma*P;
    F = [F, Phi <= -epsl*eye(n)]; %#ok<AGROW>
end
sol = optimize(F, [], sdpsettings('solver', 'sedumi', 'verbose', 0));
S.problem = sol.problem;
S.info = sol.info;
S.sigma = sigma;
S.feasible = false;
if sol.problem ~= 0 || any(isnan(double(P(:)))), return, end
Pn = double(P);
res = -Inf;
for k = 1:r
    Rk = double(R{k});
    Phi = Avert{k}.'*Pn + Pn*Avert{k} - C.'*Rk.' - Rk*C + 2*sigma*Pn;
    res = max(res, max(eig((Phi + Phi.')/2)) + epsl);
end
S.residual = res;
S.feasible = res <= 1e-9 && min(eig(Pn)) >= 1 - 1e-6;
end
