function S = lmi_lipschitz_observer(Avert, C, a, epsl, opt)
%LMI_LIPSCHITZ_OBSERVER  Vertex LMIs of the Lipschitz polytopic observer.
%
%   S = lmi_lipschitz_observer(Avert, C, a, epsl, opt)
%
%   Feasibility problem in (P, R_k, eta, lambda), k = 1..r:
%
%     [ Phi_k + a I    P        eta I   ]
%     [ P             -eta I    0       ]  <= -epsl I ,
%     [ eta I          0       -lambda I]
%
%     Phi_k = A_k' P + P A_k - C' R_k' - R_k C ,   L_k = P \ R_k ,
%     P >= Pmin I ,   lambda <= epsl + eta .
%
%   Inputs
%     Avert  r-by-1 cell of vertex matrices
%     C      output matrix
%     a      constant added on the diagonal of the (1,1) block
%     epsl   strictness margin
%     opt    optional structure
%              .Rzero  true -> R_k = 0 (no output injection at all)
%              .Pmin   lower bound on P (default epsl)
%
%   Output S: feasible flag, YALMIP diagnostic, P, L, R, eta, lambda,
%   gamma = sqrt(eta/lambda), eigenvalues and condition number of P,
%   worst a posteriori residual of the LMIs and closed-loop vertex
%   spectral abscissa.

if nargin < 5, opt = struct(); end
if ~isfield(opt, 'Rzero'), opt.Rzero = false; end
if ~isfield(opt, 'Pmin'),  opt.Pmin = epsl;   end

yalmip('clear');
r = numel(Avert);  n = size(Avert{1}, 1);  m = size(C, 1);
P   = sdpvar(n, n, 'symmetric');
eta = sdpvar(1, 1);
lam = sdpvar(1, 1);
R   = cell(r, 1);
F   = [P >= opt.Pmin*eye(n), lam <= epsl + eta];
for k = 1:r
    if opt.Rzero
        R{k} = zeros(n, m);
    else
        R{k} = sdpvar(n, m, 'full');
    end
    F = [F, lmiBlock(Avert{k}, C, P, R{k}, eta, lam, a) <= -epsl*eye(3*n)]; %#ok<AGROW>
end
sol = optimize(F, [], sdpsettings('solver', 'sedumi', 'verbose', 0));

S.problem = sol.problem;
S.info    = sol.info;
S.a = a;  S.epsl = epsl;  S.opt = opt;
if any(isnan(double(P(:))))
    S.feasible = false;  return
end
Pn = full(double(P));  Pn = (Pn + Pn.')/2;
etan = double(eta);  lamn = double(lam);
S.P = Pn;  S.eta = etan;  S.lambda = lamn;
S.gamma = sqrt(max(etan, 0)/max(lamn, eps));
S.eigP = sort(eig(Pn)).';
S.condP = cond(Pn);
S.L = cell(r, 1);  S.R = cell(r, 1);
res = -Inf;  absc = -Inf;
for k = 1:r
    Rk = full(double(R{k}));
    S.R{k} = Rk;
    S.L{k} = Pn \ Rk;
    M = lmiBlock(Avert{k}, C, Pn, Rk, etan, lamn, a);
    res  = max(res, max(eig((M + M.')/2)) + epsl);
    absc = max(absc, max(real(eig(Avert{k} - S.L{k}*C))));
end
S.residual = res;                 % <= 0 when the LMIs hold a posteriori
S.absc = absc;                    % worst vertex closed-loop abscissa
S.feasible = (sol.problem == 0) && res <= 1e-9 && min(S.eigP) >= opt.Pmin*(1 - 1e-6);
end

function M = lmiBlock(A, C, P, R, eta, lam, a)
n = size(A, 1);
Phi = A.'*P + P*A - C.'*R.' - R*C + a*eye(n);
M = [Phi, P, eta*eye(n);
     P, -eta*eye(n), zeros(n);
     eta*eye(n), zeros(n), -lam*eye(n)];
end
