function S = lmi_proto_observer(Avert, C, alpha, beta, mode)
%LMI_PROTO_OBSERVER  Vertex LMIs of the prototype polytopic depth observer
%                    (decay rate, Lipschitz margin and disk region), Chapter 2.
%
%   S = lmi_proto_observer(Avert, C, alpha, beta, mode)
%
%   Decision variables P = P', R_k (3-by-2), gamma; for every vertex k,
%     M1_k = Phi_k + 2 alpha P                 <= -1e-12 I,
%     M2   = [-2 alpha P + gamma I, P; P, -I]  <= -1e-20 I,
%     M3_k = [beta P, P A_k - R_k C; (.)', beta P] >= 1e-20 I,
%     P >= 1e-20 I,   Phi_k = A_k'P + P A_k - R_k C - C'R_k',
%   and L_k = P \ R_k (margins of the reference script).
%   mode 'feas'     : feasibility problem, no objective (reference script)
%        'maxgamma' : maximise gamma
%
%   Output: solver code, P, gamma, gains, a posteriori residuals of the
%   three families of inequalities (positive = violated), eigenvalues of
%   P and worst vertex closed-loop spectral abscissa.
if nargin < 5, mode = 'feas'; end
yalmip('clear');
r = numel(Avert);  n = size(Avert{1}, 1);  m = size(C, 1);
P = sdpvar(n, n, 'symmetric');  g = sdpvar(1, 1);
R = cell(r, 1);
M2 = [-2*alpha*P + g*eye(n), P; P, -eye(n)];
F = [M2 <= -1e-20*eye(2*n), P >= 1e-20*eye(n)];
M1 = cell(r, 1);  M3 = cell(r, 1);
for k = 1:r
    R{k} = sdpvar(n, m, 'full');
    PN = P*Avert{k} - R{k}*C;
    M1{k} = PN + PN.' + 2*alpha*P;
    M3{k} = [beta*P, PN; PN.', beta*P];
    F = [F, M1{k} <= -1e-12*eye(n), M3{k} >= 1e-20*eye(2*n)]; %#ok<AGROW>
end
if strcmp(mode, 'maxgamma'), obj = -g; else, obj = []; end
sol = optimize(F, obj, sdpsettings('solver', 'sedumi', 'verbose', 0));
S.problem = sol.problem;  S.info = sol.info;
Pn = value(P);  Pn = (Pn + Pn.')/2;  S.P = Pn;  S.gamma = value(g);
S.eigP = sort(eig(Pn)).';
S.L = cell(r, 1);  S.res1 = -Inf;  S.res3 = -Inf;  S.absc = -Inf;
for k = 1:r
    Rk = value(R{k});
    S.L{k} = Pn\Rk;
    m1 = value(M1{k});  m3 = value(M3{k});
    S.res1 = max(S.res1, max(eig((m1 + m1.')/2)));
    S.res3 = max(S.res3, -min(eig((m3 + m3.')/2)));
    S.absc = max(S.absc, max(real(eig(Avert{k} - S.L{k}*C))));
end
m2 = value(M2);  S.res2 = max(eig((m2 + m2.')/2));
S.feasibleCheck = S.res1 <= 0 && S.res2 <= 0 && S.res3 <= 0 && min(S.eigP) > 0;
end
