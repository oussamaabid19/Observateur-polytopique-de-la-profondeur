function [Lam, subsets] = ts_walsh(Lvert, N)
%TS_WALSH  Multilinear (Walsh) expansion of a TS-interpolated matrix.
%
%   [Lam, subsets] = ts_walsh(Lvert, N)
%
%   With the normalized scheduling variables
%       xi_i = (2 p_i - pmax_i - pmin_i)/(pmax_i - pmin_i)  in [-1, 1],
%   the TS weights read h_k = prod_i (1 + s_ki xi_i)/2, s_ki = 2 b_ki - 1,
%   and the interpolated matrix  L(xi) = sum_k h_k L_k  is the multilinear
%   polynomial
%       L(xi) = sum_{S subset of {1..N}} Lam_S prod_{i in S} xi_i ,
%       Lam_S = 2^-N sum_k ( prod_{i in S} s_ki ) L_k .
%
%   Lvert   : 2^N-by-1 cell of vertex matrices (numbering of ts_system.m)
%   Lam     : 2^N-by-1 cell of coefficients Lam_S
%   subsets : 2^N-by-N logical matrix, row j marks the variables of S_j
%             (row 1 = empty set = constant part).

r   = 2^N;
bin = dec2bin(0:r-1, N) - '0';
s   = 2*bin - 1;                              % vertex signs
subsets = logical(dec2bin(0:r-1, N) - '0');   % same enumeration for S
Lam = cell(r, 1);
for j = 1:r
    Lj = zeros(size(Lvert{1}));
    for k = 1:r
        Lj = Lj + prod(s(k, subsets(j, :)))*Lvert{k};
    end
    Lam{j} = Lj/r;
end
end
