function V = se3_vee(X)
%SE3_VEE  Inverse of SE3_HAT: twist [v; omega] of a 4-by-4 se(3) matrix.
V = [X(1:3, 4); X(3, 2); X(1, 3); X(2, 1)];
end
