function dq = se3_feature_rate(T0c, V, P0)
%SE3_FEATURE_RATE  Exact time derivative of [x; y; chi] obtained from the pose.
%
%   dq = se3_feature_rate(T0c, V, P0)
%
%   The derivative of the pose is taken from its own kinematics,
%   dT/dt = T hat(V), i.e. dR/dt and dp/dt are evaluated as matrices; the
%   derivative of Pc = R'(P0 - p) follows by the product rule,
%       dPc/dt = (dR/dt)'(P0 - p) - R' dp/dt ,
%   and is pushed through the exact Jacobian of the projection
%       dx/dt = (dX - x dZ)/Z,  dy/dt = (dY - y dZ)/Z,  dchi/dt = -dZ/Z^2 .
%   No interaction matrix is used: comparing dq with cam_sys tests the
%   image-plane model against the rigid-body kinematics without any
%   truncation error.
R = T0c(1:3, 1:3);  p = T0c(1:3, 4);
dT = T0c*se3_hat(V);
dR = dT(1:3, 1:3);  dp = dT(1:3, 4);
Pc  = R.'*(P0(1:3, :) - p);
dPc = dR.'*(P0(1:3, :) - p) - R.'*dp;
Z = Pc(3, :);  x = Pc(1, :)./Z;  y = Pc(2, :)./Z;
dq = [(dPc(1, :) - x.*dPc(3, :))./Z;
      (dPc(2, :) - y.*dPc(3, :))./Z;
      -dPc(3, :)./Z.^2];
end
