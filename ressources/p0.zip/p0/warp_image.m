function [Iw, mask] = warp_image(I, G, sz)
%WARP_IMAGE  Image of a plane after a homography, by inverse warping.
%
%   [Iw, mask] = warp_image(I, G, sz)
%
%   I    source image (grey levels, double), pixel (u,v) at I(v,u),
%        with u, v starting at 1 as in MATLAB
%   G    pixel homography from the source image to the new image, p' ~ G p
%   sz   [width height] of the new image (default: size of I)
%
%   Every pixel p' of the new image is mapped back by G^{-1} to the source
%   image and the intensity is interpolated bilinearly (interp2).  Pixels
%   whose antecedent falls outside the source image get 0 and mask = false.
%   Mapping back avoids the holes that a forward projection would leave.
if nargin < 3 || isempty(sz), sz = [size(I, 2), size(I, 1)]; end
[uo, vo] = meshgrid(1:sz(1), 1:sz(2));
r = G\[uo(:).'; vo(:).'; ones(1, numel(uo))];
us = reshape(r(1, :)./r(3, :), size(uo));
vs = reshape(r(2, :)./r(3, :), size(uo));
Iw = interp2(double(I), us, vs, 'linear');
mask = ~isnan(Iw);
Iw(~mask) = 0;
end
