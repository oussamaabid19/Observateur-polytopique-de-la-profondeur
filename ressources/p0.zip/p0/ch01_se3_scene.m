function sc = ch01_se3_scene()
%CH01_SE3_SCENE  Eye-in-hand scene of Chapter 1 (frames, object, camera).
%
%   World frame 0, end effector e, camera c rigidly mounted on e, planar
%   square object o (side 0.5 m) placed 1.5 m in front of the camera on its
%   optical axis.  Poses with ht_xyzrpy (VSToolbox convention).  The moving
%   camera of Chapters 1 and 2 starts from T0c.
sc.T0e = ht_xyzrpy(-0.2, 0.3, 0.8, pi/6, pi/2, pi/12);
sc.Tec = ht_xyzrpy(0.03, -0.02, 0.5, pi/4, 0, 0);
sc.Tco = ht_xyzrpy(0, 0, 1.5, 0, 0, 0);
sc.T0c = sc.T0e*sc.Tec;
sc.T0o = sc.T0c*sc.Tco;
sc.Po  = [0.25 0.25 -0.25 -0.25; -0.25 0.25 0.25 -0.25; 0 0 0 0; 1 1 1 1];
sc.P0  = sc.T0o*sc.Po;
sc.K   = [1000 0 256; 0 1000 256; 0 0 1];
sc.imsize = [512 512];
end
