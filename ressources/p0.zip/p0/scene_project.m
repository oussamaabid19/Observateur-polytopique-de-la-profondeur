function [q, uv, Pc, vis] = scene_project(T0c, P0, K, imsize)
%SCENE_PROJECT  Coordinates of world points in the camera and their image.
%
%   [q, uv, Pc, vis] = scene_project(T0c, P0, K, imsize)
%
%   T0c    camera pose in the world frame (4-by-4)
%   P0     3-by-N (or 4-by-N homogeneous) world coordinates of the points
%   K      3-by-3 intrinsic matrix
%   imsize [width height] in pixels (optional)
%
%   Pc  = R0c' (P0 - p0c)               (3-by-N, camera frame)
%   q   = [X/Z; Y/Z; 1/Z]               (3-by-N, state of the image model)
%   uv  = pixel coordinates K [x; y; 1] (2-by-N)
%   vis = 1-by-N logical, true if Z > 0 and the pixel lies in the image.
R = T0c(1:3, 1:3);  p = T0c(1:3, 4);
Pc = R.'*(P0(1:3, :) - p);
Z = Pc(3, :);
q = [Pc(1, :)./Z; Pc(2, :)./Z; 1./Z];
m = K*[q(1:2, :); ones(1, size(q, 2))];
uv = m(1:2, :);
if nargin < 4 || isempty(imsize)
    vis = Z > 0;
else
    vis = Z > 0 & uv(1, :) >= 0 & uv(1, :) <= imsize(1) - 1 & ...
          uv(2, :) >= 0 & uv(2, :) <= imsize(2) - 1;
end
end
