function V = sfm_motion(name, t, prm)
%SFM_MOTION  Camera twists (body frame) used in Chapters 1 and 2.
%
%   V = sfm_motion(name, t, prm)   returns [v; omega] at time t.
%
%   'M1'  motion of the original demonstration scripts
%         v = (0.7 cos 2pi t, 0.5 cos(pi t/2), cos pi t),
%         omega = (0.1 cos(pi t/2), 0, 0.1)
%   'M2'  smooth motion  kappa*(0.35 cos .7t, .25 sin .5t, .12 cos .3t,
%         .04 sin .4t, .03 cos .6t, .05);  prm.kappa (default 1)
%   'M3'  fixation motion proposed in the book: the camera rotates with
%         omega = (a sin .8t, a cos .5t, .1) and translates with
%         v = -omega x (0,0,d) - (0,0,d'),  d(t) = d0 - da cos(.5t),
%         which keeps the point (0,0,d(t)) of the optical axis fixed in
%         the image; prm.a (default 0.25), prm.d0 (1.8), prm.da (0.3).
%   'MU1' first scenario of the published UIO study (receding camera)
%         v = (0.2 e^{-0.05t}, 0.08 cos(pi t/5), -0.2 cos(pi t) - 0.5),
%         omega = (0.02, 0, 0.01)
%   'MU2' second scenario of the published UIO study (receding camera)
%         v = (0.05 sin(pi t/10), 0.02 + 0.01 t, -1/(0.07 t + 1)),
%         omega = (0.02, -0.03 cos(pi t/5), 0)
%   'MH'  slow motion of the planar-scene (homography) simulations
%         v = (-.02 e^{-.02t}, -.05 sin(pi t/5) + .0005 t, -.05 e^{-.02t} - .03),
%         omega = (.01, -.06 cos(pi t/2), .05 cos(pi t/4))

if nargin < 3, prm = struct(); end
switch name
    case 'M1'
        V = [0.7*cos(2*pi*t); 0.5*cos(pi*t/2); cos(pi*t); 0.1*cos(pi*t/2); 0; 0.1];
    case 'M2'
        k = getf(prm, 'kappa', 1);
        V = k*[0.35*cos(0.7*t); 0.25*sin(0.5*t); 0.12*cos(0.3*t); ...
               0.04*sin(0.4*t); 0.03*cos(0.6*t); 0.05];
    case 'M3'
        a = getf(prm, 'a', 0.25);  d0 = getf(prm, 'd0', 1.8);  da = getf(prm, 'da', 0.3);
        w = [a*sin(0.8*t); a*cos(0.5*t); 0.1];
        d = d0 - da*cos(0.5*t);  dd = 0.5*da*sin(0.5*t);
        v = -cross(w, [0; 0; d]) - [0; 0; dd];
        V = [v; w];
    case 'MU1'
        V = [0.2*exp(-0.05*t); 0.08*cos(pi*t/5); -0.2*cos(pi*t) - 0.5; 0.02; 0; 0.01];
    case 'MU2'
        V = [0.05*sin(pi*t/10); 0.02 + 0.01*t; -1/(0.07*t + 1); 0.02; -0.03*cos(pi*t/5); 0];
    case 'MH'
        V = [-0.02*exp(-0.02*t); -0.05*sin(pi*t/5) + 0.0005*t; -0.05*exp(-0.02*t) - 0.03; ...
             0.01; -0.06*cos(pi*t/2); 0.05*cos(pi*t/4)];
    otherwise
        error('sfm_motion:name', 'Unknown motion %s.', name);
end
end

function x = getf(s, f, d)
if isfield(s, f), x = s.(f); else, x = d; end
end
