function dq = cam_sys(q, v, omega)
%CAM_SYS  Image-plane kinematics of a static point feature (pinhole camera).
%
%   dq = cam_sys(q, v, omega)
%
%   State   q     = [x; y; chi]   normalized image coordinates and inverse
%                                 depth chi = 1/Z of the point.
%   Inputs  v     = [vx; vy; vz]  camera linear velocity  (camera frame)
%           omega = [wx; wy; wz]  camera angular velocity (camera frame)
%   Output  dq    = d q / dt
%
%   Model (book, Chapter 1, Eq. (ch1:model)):
%       ds/dt   = f_m(s, omega) + Omega(s, v) * chi
%       dchi/dt = vz*chi^2 + (y*wx - x*wy)*chi
%   with
%       f_m   = [ x*y, -(1+x^2),  y ;  1+y^2, -x*y, -x ] * omega
%       Omega = [ x*vz - vx ; y*vz - vy ]

x   = q(1);
y   = q(2);
chi = q(3);

vx = v(1); vy = v(2); vz = v(3);
wx = omega(1); wy = omega(2);

Lw    = [x*y, -(1 + x^2),  y;
         1 + y^2, -x*y,  -x];          % rotational part of the interaction matrix
Omega = [x*vz - vx;
         y*vz - vy];                   % translational part (multiplies chi)

ds   = Lw*omega(:) + Omega*chi;
dchi = vz*chi^2 + (y*wx - x*wy)*chi;

dq = [ds; dchi];
end
