function X = se3_hat(V)
%SE3_HAT  4-by-4 matrix of a twist V = [v; omega] (element of se(3)).
%
%   X = [ [omega]_x  v ; 0 0 0 0 ],  [omega]_x a = omega x a.
v = V(1:3);  w = V(4:6);
X = [0 -w(3) w(2) v(1);
     w(3) 0 -w(1) v(2);
     -w(2) w(1) 0 v(3);
     0 0 0 0];
end
