function q = ch01_project(P)
%CH01_PROJECT  Perspective projection of camera-frame points to [x, y, chi].
%
%   q = ch01_project(P)
%
%   P : n-by-3 array of camera-frame coordinates [X Y Z] (one point per row)
%   q : n-by-3 array [x y chi] with x = X/Z, y = Y/Z, chi = 1/Z.

Z = P(:, 3);
q = [P(:, 1)./Z, P(:, 2)./Z, 1./Z];
end
