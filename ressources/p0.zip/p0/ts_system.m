function [A, h, Avert, r] = ts_system(p, params)
%TS_SYSTEM  Sector-nonlinearity (Takagi-Sugeno) reconstruction of an affine
%           parameter-dependent matrix.
%
%   [A, h, Avert, r] = ts_system(p, params)
%
%   The matrix is assumed affine in the N scheduling variables p_i:
%       A(p) = A0 + sum_{i=1}^{N} p_i * A_i ,   p_i in [pmin_i, pmax_i].
%   It is rewritten as the polytopic (TS) model
%       A(p) = sum_{k=1}^{r} h_k(p) * A_k ,     r = 2^N ,
%   where A_k are the vertex matrices and h_k the TS weights.
%
%   Inputs
%     p              N-by-1 vector of scheduling variables (may be empty)
%     params.Acell   1-by-N cell {A_1, ..., A_N}
%     params.pmin    N-by-1 lower bounds
%     params.pmax    N-by-1 upper bounds
%     params.A0      (optional) constant part, zeros by default
%
%   Outputs
%     A      reconstructed matrix sum_k h_k A_k   ([] if p is empty)
%     h      r-by-1 vector of weights             ([] if p is empty)
%     Avert  r-by-1 cell array of vertex matrices
%     r      number of vertices (2^N)
%
%   Vertex numbering. Vertex k (k = 1..r) is associated with the binary word
%   b = dec2bin(k-1, N): b_i = 0 selects pmin_i, b_i = 1 selects pmax_i, the
%   first scheduling variable being the most significant bit.
%
%   Weights. For each p_i the two scalar membership functions are
%       w_i^0(p_i) = (pmax_i - p_i)/(pmax_i - pmin_i),  w_i^1 = 1 - w_i^0,
%   and h_k(p) = prod_i w_i^{b_i}(p_i).
%   Inside the box the h_k are non-negative and sum to one (convex sum).
%   Outside the box they still sum to one and still reproduce A(p) exactly,
%   but some of them become negative (the convex-sum property is lost).

Acell = params.Acell;
pmin  = params.pmin(:);
pmax  = params.pmax(:);
if isfield(params, 'A0') && ~isempty(params.A0)
    A0 = params.A0;
else
    A0 = zeros(size(Acell{1}));
end

N   = numel(Acell);
r   = 2^N;
bin = dec2bin(0:r-1, N) - '0';         % r-by-N binary matrix

if any(pmax <= pmin)
    error('ts_system:BadBounds', 'Each bound must satisfy pmin < pmax.');
end

% Vertex matrices
Avert = cell(r, 1);
for k = 1:r
    Ak = A0;
    for i = 1:N
        if bin(k, i) == 0
            Ak = Ak + pmin(i)*Acell{i};
        else
            Ak = Ak + pmax(i)*Acell{i};
        end
    end
    Avert{k} = Ak;
end

if isempty(p)                           % vertices-only mode
    A = [];
    h = [];
    return
end

p = p(:);
if numel(p) ~= N
    error('ts_system:BadDim', 'p must be N-by-1 with N = numel(Acell).');
end

% Scalar membership functions
w = zeros(N, 2);
for i = 1:N
    w(i, 1) = (pmax(i) - p(i))/(pmax(i) - pmin(i));   % b_i = 0 (pmin)
    w(i, 2) = 1 - w(i, 1);                            % b_i = 1 (pmax)
end

% Global weights h_k = prod_i w_i^{b_i}
h = ones(r, 1);
for k = 1:r
    for i = 1:N
        h(k) = h(k)*w(i, bin(k, i) + 1);
    end
end

% Polytopic reconstruction
A = zeros(size(A0));
for k = 1:r
    A = A + h(k)*Avert{k};
end
end
