function T = se3_exp(V)
%SE3_EXP  Exponential map of se(3) in closed form.
%
%   T = se3_exp(V),  V = [v; omega],  T = expm(se3_hat(V)) = [R J v; 0 1]
%
%   R = I + a W + b W^2 (Rodrigues),  J = I + b W + c W^2,
%   a = sin(t)/t,  b = (1-cos t)/t^2,  c = (t - sin t)/t^3,  t = |omega|.
%   Taylor expansions are used for small t, so that T is a rigid
%   transformation to round-off for every V.
v = V(1:3);  w = V(4:6);
t = norm(w);
W = [0 -w(3) w(2); w(3) 0 -w(1); -w(2) w(1) 0];
if t < 1e-4
    t2 = t^2;
    a = 1 - t2/6 + t2^2/120;
    b = 1/2 - t2/24 + t2^2/720;
    c = 1/6 - t2/120 + t2^2/5040;
else
    a = sin(t)/t;  b = (1 - cos(t))/t^2;  c = (t - sin(t))/t^3;
end
W2 = W*W;
R = eye(3) + a*W + b*W2;
J = eye(3) + b*W + c*W2;
T = [R, J*v; 0 0 0 1];
end
