function dq = cam_ts(q, v, omega, params)
%CAM_TS  Takagi-Sugeno (polytopic) form of the point-feature kinematics.
%
%   dq = cam_ts(q, v, omega, params)
%
%   q = [x; y; chi],  v = [vx; vy; vz],  omega = [wx; wy; wz]
%
%   Quasi-LPV model:   dq/dt = A(p) q + B(s) omega
%       A(p) = p1*A_1 + p2*A_2 + p3*A_3   (single non-zero third column)
%       p1 = x*vz - vx,  p2 = y*vz - vy,  p3 = vz*chi + y*wx - x*wy
%       B(s) = [ x*y, -(1+x^2), y ; 1+y^2, -x*y, -x ; 0, 0, 0 ]
%   A(p) is evaluated through the TS convex combination of ts_system.m.
%   params is the structure expected by ts_system (Acell, pmin, pmax, A0).

x = q(1); y = q(2); chi = q(3);
vx = v(1); vy = v(2); vz = v(3);
wx = omega(1); wy = omega(2);

p = [x*vz - vx;
     y*vz - vy;
     vz*chi + y*wx - x*wy];

A = ts_system(p, params);
B = [x*y, -(1 + x^2),  y;
     1 + y^2, -x*y,  -x;
     0, 0, 0];

dq = A*q(:) + B*omega(:);
end
