function Tg = se3_rkmk4(Vfun, T0, tg)
%SE3_RKMK4  Runge--Kutta--Munthe-Kaas method of order 4 for dT/dt = T*hat(V(t)).
%
%   Tg = se3_rkmk4(Vfun, T0, tg)
%
%   Vfun  handle, Vfun(t) = [v; omega] (body twist, camera frame)
%   T0    initial pose (4-by-4)
%   tg    increasing time grid (the step may vary)
%   Tg    4-by-4-by-numel(tg) array of poses
%
%   On each step T(t_n + s) = T_n exp(Theta(s)), and Theta solves
%   dTheta/ds = dexp^{-1}_{-Theta}(hat V) = A + [Theta,A]/2 + [Theta,[Theta,A]]/12 + ...
%   (series truncated after the second bracket, which is sufficient for
%   order four).  The classical RK4 tableau is applied to Theta in the
%   vector space se(3), and the step is mapped back with the closed-form
%   exponential.  Every computed pose is therefore a rigid transformation
%   to round-off, whatever the step.

n = numel(tg);
Tg = zeros(4, 4, n);
Tg(:, :, 1) = T0;
T = T0;
for k = 1:n-1
    t = tg(k);  h = tg(k+1) - t;
    A1 = se3_hat(Vfun(t));
    A2 = se3_hat(Vfun(t + h/2));
    A4 = se3_hat(Vfun(t + h));
    K1 = h*A1;
    Th = K1/2;           K2 = h*dexpinv(Th, A2);
    Th = K2/2;           K3 = h*dexpinv(Th, A2);
    Th = K3;             K4 = h*dexpinv(Th, A4);
    Theta = (K1 + 2*K2 + 2*K3 + K4)/6;
    T = T*se3_exp(se3_vee(Theta));
    Tg(:, :, k+1) = T;
end
end

function Y = dexpinv(Th, A)
B1 = Th*A - A*Th;
Y = A + B1/2 + (Th*B1 - B1*Th)/12;
end
