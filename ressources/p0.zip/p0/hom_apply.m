function [q, w] = hom_apply(G, p)
%HOM_APPLY  Projective map of points: q ~ G [p; 1].
%
%   [q, w] = hom_apply(G, p)
%
%   p  2-by-N points (pixels or normalized coordinates)
%   q  2-by-N mapped points,  w  1-by-N third homogeneous coordinate
%      (w > 0 means that the point stays in front of the second camera
%      when G is the homography of a plane in front of both cameras)
r = G*[p; ones(1, size(p, 2))];
w = r(3, :);
q = r(1:2, :)./w;
end
