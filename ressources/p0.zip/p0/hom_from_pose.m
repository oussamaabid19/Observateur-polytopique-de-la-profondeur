function [H, n, d] = hom_from_pose(Tc0, n0, d0)
%HOM_FROM_POSE  Euclidean homography induced by a plane between two views.
%
%   [H, n, d] = hom_from_pose(Tc0, n0, d0)
%
%   Tc0     4-by-4 transformation mapping the coordinates of a point in the
%           first camera frame to the second: P = R P0 + t, [R t] = Tc0(1:3,:)
%   n0, d0  plane n0' P0 = d0 in the first frame (|n0| = 1, d0 > 0)
%
%   H = R + t n0'/d0   (normalized coordinates: Z m = H Z0 m0)
%   n = R n0,  d = d0 + n' t   plane parameters in the second frame,
%   so that det(H) = d/d0.
R = Tc0(1:3, 1:3);  t = Tc0(1:3, 4);
H = R + t*n0(:).'/d0;
n = R*n0(:);
d = d0 + n.'*t;
end
