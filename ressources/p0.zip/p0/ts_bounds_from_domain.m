function [pmin, pmax] = ts_bounds_from_domain(D)
%TS_BOUNDS_FROM_DOMAIN  A priori bounds of the scheduling variables of the
%                       point-feature quasi-LPV model, by interval arithmetic.
%
%   [pmin, pmax] = ts_bounds_from_domain(D)
%
%   D.x, D.y     1-by-2 intervals of the normalized image coordinates
%   D.chi        1-by-2 interval of the inverse depth (chi > 0)
%   D.v          3-by-2 intervals of [vx; vy; vz]
%   D.w          3-by-2 intervals of [wx; wy; wz]
%
%   p1 = x*vz - vx,   p2 = y*vz - vy,   p3 = vz*chi + y*wx - x*wy
%
%   The result is an outer (guaranteed) enclosure of the range of p over
%   the operating domain D; it is generally conservative because the
%   dependency between factors is ignored.

p1 = isub(imul(D.x, D.v(3, :)), D.v(1, :));
p2 = isub(imul(D.y, D.v(3, :)), D.v(2, :));
p3 = isub(iadd(imul(D.v(3, :), D.chi), imul(D.y, D.w(1, :))), imul(D.x, D.w(2, :)));

pmin = [p1(1); p2(1); p3(1)];
pmax = [p1(2); p2(2); p3(2)];
end

function c = imul(a, b)
prods = [a(1)*b(1), a(1)*b(2), a(2)*b(1), a(2)*b(2)];
c = [min(prods), max(prods)];
end

function c = iadd(a, b)
c = [a(1) + b(1), a(2) + b(2)];
end

function c = isub(a, b)
c = [a(1) - b(2), a(2) - b(1)];
end
