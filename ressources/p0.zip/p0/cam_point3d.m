function dP = cam_point3d(P, v, omega)
%CAM_POINT3D  Velocity of a static 3-D point expressed in a moving camera frame.
%
%   dP = cam_point3d(P, v, omega)
%
%   P     = [X; Y; Z]  coordinates of the point in the camera frame F_c
%   v     = camera linear velocity  (expressed in F_c)
%   omega = camera angular velocity (expressed in F_c)
%
%   For a point at rest in the world frame:
%       dP/dt = -v - omega x P
%
%   This function is used only as an independent geometric ground truth:
%   the image measurements are obtained afterwards by the perspective
%   projection x = X/Z, y = Y/Z, chi = 1/Z (see ch01_project.m).

dP = -v(:) - cross(omega(:), P(:));
end
