function T = ht_xyzrpy(x, y, z, phi, theta, psi)
%HT_XYZRPY  Homogeneous transformation from a translation and Euler angles.
%
%   T = ht_xyzrpy(x, y, z, phi, theta, psi)
%
%   T = [R p; 0 1],  p = [x; y; z],  R = Rz(phi) * Ry(theta) * Rx(psi).
%
%   This is the convention of the constructor ht('xyzrpy', ...) of the
%   VSToolbox: the first angle is a rotation about z, the second about the
%   (new) y axis and the third about the (new) x axis.  The parametrisation
%   is singular at theta = +-pi/2, where R depends only on phi - psi.

if nargin < 4, phi = 0; theta = 0; psi = 0; end
cz = cos(phi);   sz = sin(phi);
cy = cos(theta); sy = sin(theta);
cx = cos(psi);   sx = sin(psi);
Rz = [cz -sz 0; sz cz 0; 0 0 1];
Ry = [cy 0 sy; 0 1 0; -sy 0 cy];
Rx = [1 0 0; 0 cx -sx; 0 sx cx];
T = [Rz*Ry*Rx, [x; y; z]; 0 0 0 1];
end
