function dq = cam_sys_px(q, v, omega, ku, kv, dku, dkv)
%CAM_SYS_PX  Point kinematics in centred pixel coordinates.
%
%   dq = cam_sys_px(q, v, omega, ku, kv, dku, dkv)
%
%   q = [u; v; chi], u = ku x, v = kv y (pixels measured from the principal
%   point), chi = 1/Z.  ku, kv are the focal lengths in pixels and dku, dkv
%   their time derivatives (zoom); with dku = dkv = 0 and ku = kv = 1 the
%   model reduces to cam_sys.
%
%   du/dt = (dku/ku) u + ku dx/dt,   dv/dt = (dkv/kv) v + kv dy/dt,
%   with dx/dt, dy/dt, dchi/dt given by cam_sys at x = u/ku, y = v/kv.
if nargin < 6, dku = 0; dkv = 0; end
x = q(1)/ku;  y = q(2)/kv;
dn = cam_sys([x; y; q(3)], v, omega);
dq = [dku/ku*q(1) + ku*dn(1);
      dkv/kv*q(2) + kv*dn(2);
      dn(3)];
end
