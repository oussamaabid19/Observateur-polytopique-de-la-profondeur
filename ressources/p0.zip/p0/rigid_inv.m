function Ti = rigid_inv(T)
%RIGID_INV  Inverse of a rigid transformation, T^{-1} = [R' -R'p; 0 1].
%
%   Exact only if R is a rotation matrix.  For a matrix that has drifted
%   away from SE(3) it differs from inv(T); the difference is used in
%   Chapter 1 as an indicator of the drift.
R = T(1:3, 1:3);  p = T(1:3, 4);
Ti = [R.', -R.'*p; 0 0 0 1];
end
